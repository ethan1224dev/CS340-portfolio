from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. 
        # 
        # Connection Variables 
        # 
        USER = username
        PASS = password
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER, PASS, HOST, PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # method to implement the C in CRUD.
    def create(self, data):
        """Insert a document into the animals collection"""
        if data is not None: 
            try:
                self.collection.insert_one(data)  # data should be dictionary
                return True
            except Exception as e:
                print(f"Error creating document: {e}")
                return False        
        else: 
            raise Exception("Nothing to save, because data parameter is empty")

    # Read method to implement the R in CRUD.
    def read(self, query):
        """Query for documents from the animals collection"""
        if query is not None:
            try:
                cursor = self.collection.find(query)
                return list(cursor)
            except Exception as e:
                print(f"Error reading documents: {e}")
                return []
        else:
            # If no query provided, return all documents
            try:
                cursor = self.collection.find({})
                return list(cursor)
            except Exception as e:
                print(f"Error reading documents: {e}")
                return []

    # Update method to implement the U in CRUD.
    def update(self, query, new_values):
        """Update documents matching the query with new values"""
        if query is not None and new_values is not None:
            try:
                result = self.collection.update_many(query, {"$set": new_values})
                return result.modified_count
            except Exception as e:
                print(f"Error updating documents: {e}")
                return 0
        else:
            raise Exception("Query and new_values cannot be empty")

    # Delete method to implement the D in CRUD.
    def delete(self, query):
        """Delete documents matching the query from the animals collection"""
        if query is not None:
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except Exception as e:
                print(f"Error deleting documents: {e}")
                return 0
        else:
            raise Exception("Query cannot be empty")